﻿// Program 3
// CIS 199-01
// Due: 4/5/16
// By: Emily Zeng
// This application calculates the earliest registration date
// and time for an undergraduate student given their credit hours
// and last name. Starting from Solution 3 of Program 2, build 
// decision structure to use parallel arrays.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Prog2
{
    public partial class RegForm : Form
    {
        public RegForm()
        {
            InitializeComponent();
        }

        // Precondition: Credit hours entered is a valid integer >=0, name entered is a valid string
        // Postcondition: Returns date and time of registration 

        private void findRegTimeBtn_Click(object sender, EventArgs e)
        {
            const float SENIOR_HOURS = 90;    // Min hours for Senior
            const float JUNIOR_HOURS = 60;    // Min hours for Junior
            const float SOPHOMORE_HOURS = 30; // Min hours for Soph.

            const string DAY1 = "March 30";  // 1st day of registration
            const string DAY2 = "March 31";  // 2nd day of registration
            const string DAY3 = "April 1";   // 3rd day of registration
            const string DAY4 = "April 4";   // 4th day of registration
            const string DAY5 = "April 5";   // 5th day of registration
            const string DAY6 = "April 6";   // 6th day of registration

            const string TIME1 = "8:30 AM";  // 1st time block
            const string TIME2 = "10:00 AM"; // 2nd time block
            const string TIME3 = "11:30 AM"; // 3rd time block
            const string TIME4 = "2:00 PM";  // 4th time block
            const string TIME5 = "4:00 PM";  // 5th time block

            string lastNameStr;       // Entered last name
            char lastNameLetterCh;    // First letter of last name, as char
            string dateStr = "Error"; // Holds date of registration
            string timeStr = "Error"; // Holds time of registration
            float creditHours;        // Entered credit hours

            if (float.TryParse(creditHrTxt.Text, out creditHours) && creditHours >= 0) // Valid hours
            {
                lastNameStr = lastNameTxt.Text;
                if (lastNameStr.Length > 0) // Empty string?
                {
                    lastNameStr = lastNameStr.ToUpper(); // Ensure upper case
                    lastNameLetterCh = lastNameStr[0];   // First char of last name

                    if (char.IsLetter(lastNameLetterCh)) // Is it a letter?
                    {

                        if (creditHours >= JUNIOR_HOURS)            // Checks if credit hours makes student a junior 
                        {
                            if (creditHours >= SENIOR_HOURS)        // Checks if credit hours make student a senior 
                            {
                                dateStr = "Wednesday, March 30th";  // If senior, assign date to dateStr
                            }
                            else
                            {
                                dateStr = "Thursday, March 31st";   // If junior, assign date to date Str
                            }

                            char[] lastInitial = { 'A', 'E', 'J', 'P', 'T' };                               // Declare array with lower end of alphabet range for registration time
                            string[] regTime = { "4:00 PM", "8:30 AM", "10:00 AM", "11:30 AM", "2:00 PM" }; // Declare array with times corresponding to lastInitial array 

                            int count = lastInitial.Length - 1; // Declare counter variable

                            while (count >= 0 && lastNameLetterCh < lastInitial[count])     // While count is >= 1, and the last name's first letter is less than the last initial in the specified index, decrement
                            {
                                --count;    // Decrement counter variable
                            }
                            timeStr = regTime[count]; // Assign value in regTime array at count index to timeStr
                        }
                        else // Else, checks if sophomore
                        {
                            if (creditHours >= SOPHOMORE_HOURS) // Checks if credit hours makes student a sophomore
                            {
                                if ((lastNameLetterCh >= 'E') && (lastNameLetterCh <= 'Q')) // Checks char against range from E-Q
                                {
                                    dateStr = "Friday, April 1st"; // Assigns E-Q last name range to date
                                }
                                else
                                {
                                    dateStr = "Monday, April 4th"; // All other register on another day
                                }

                                char[] lastInitial = { 'A', 'C', 'E', 'G', 'J', 'M', 'P', 'R', 'T', 'W' };  // Declare array with lower end of alphabet range for  registrationtime
                                string[] regTime = { "2:00 PM", "4:00 PM", "8:30 AM", "10:00 AM", "11:30 AM", "2:00 PM", "4:00 PM", "8:30 AM", "10:00 AM", "11:30 AM" };    // Declare array with times corresponding to lastInitial array 

                                int count = lastInitial.Length - 1; // Declare counter variable

                                while (count >= 0 && lastNameLetterCh < lastInitial[count])  // While count is >= 1, and the last name's first letter is less than the last initial in the specified index, decrement
                                {
                                    --count; // Decrement
                                }
                                timeStr = regTime[count]; // Assign value in regTime array at count index to timeStr
                            }
                            else // Else, freshman
                            {
                                if ((lastNameLetterCh >= 'E') && (lastNameLetterCh <= 'Q')) // Checks char against range from E-Q
                                {
                                    dateStr = "Tuesday, April 5th"; // Assign date if in range E-Q
                                }
                                else
                                {
                                    dateStr = "Wednesday, April 6th"; // Assigns date if range out of E-Q
                                }

                                char[] lastInitial = { 'A', 'C', 'E', 'G', 'J', 'M', 'P', 'R', 'T', 'W' };  // Declare array with lower end of alphabet range for registration time
                                string[] regTime = { "2:00 PM", "4:00 PM", "8:30 AM", "10:00 AM", "11:30 AM", "2:00 PM", "4:00 PM", "8:30 AM", "10:00 AM", "11:30 AM" }; // Declare array with times corresponding to lastInitial array 

                                int count = lastInitial.Length - 1; // Declare counter variable

                                while (count >= 0 && lastNameLetterCh < lastInitial[count]) // While count is >= 1, and the last name's first letter is less than the last initial in the specified index, decrement
                                {
                                    --count; // Decrement
                                }
                                timeStr = regTime[count]; // Assign value in regTime array at count index to timeStr
                            }
                        }
                        // Output results
                        dateTimeLbl.Text = dateStr + " at " + timeStr;
                    }
                    else // First char not a letter
                        MessageBox.Show("Enter valid last name!");
                }
                else // Empty textbox
                    MessageBox.Show("Enter a last name!");
            }
            else // Can't parse credit hours
                MessageBox.Show("Please enter valid credit hours earned!");
        }
    }
}
