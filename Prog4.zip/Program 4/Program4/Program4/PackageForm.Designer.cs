﻿namespace Program4
{
    partial class Program4form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.originLbl = new System.Windows.Forms.Label();
            this.destLbl = new System.Windows.Forms.Label();
            this.lengthLbl = new System.Windows.Forms.Label();
            this.widthLbl = new System.Windows.Forms.Label();
            this.heightLbl = new System.Windows.Forms.Label();
            this.weightLbl = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.addPkgBtn = new System.Windows.Forms.Button();
            this.detailsBtn = new System.Windows.Forms.Button();
            this.sendToULBtn = new System.Windows.Forms.Button();
            this.sendFromULTxtBx = new System.Windows.Forms.Button();
            this.packageListBox = new System.Windows.Forms.ListBox();
            this.originTxtBx = new System.Windows.Forms.TextBox();
            this.destinationTxtBx = new System.Windows.Forms.TextBox();
            this.lengthTxtBx = new System.Windows.Forms.TextBox();
            this.widthTxtBx = new System.Windows.Forms.TextBox();
            this.heightTxtBx = new System.Windows.Forms.TextBox();
            this.weightTxtBx = new System.Windows.Forms.TextBox();
            this.clearBtn = new System.Windows.Forms.Button();
            this.clearTextBoxBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // originLbl
            // 
            this.originLbl.AutoSize = true;
            this.originLbl.Location = new System.Drawing.Point(28, 23);
            this.originLbl.Name = "originLbl";
            this.originLbl.Size = new System.Drawing.Size(55, 13);
            this.originLbl.TabIndex = 0;
            this.originLbl.Text = "Origin Zip:";
            // 
            // destLbl
            // 
            this.destLbl.AutoSize = true;
            this.destLbl.Location = new System.Drawing.Point(30, 56);
            this.destLbl.Name = "destLbl";
            this.destLbl.Size = new System.Drawing.Size(53, 13);
            this.destLbl.TabIndex = 1;
            this.destLbl.Text = "Dest. Zip:";
            // 
            // lengthLbl
            // 
            this.lengthLbl.AutoSize = true;
            this.lengthLbl.Location = new System.Drawing.Point(40, 89);
            this.lengthLbl.Name = "lengthLbl";
            this.lengthLbl.Size = new System.Drawing.Size(43, 13);
            this.lengthLbl.TabIndex = 2;
            this.lengthLbl.Text = "Length:";
            // 
            // widthLbl
            // 
            this.widthLbl.AutoSize = true;
            this.widthLbl.Location = new System.Drawing.Point(45, 122);
            this.widthLbl.Name = "widthLbl";
            this.widthLbl.Size = new System.Drawing.Size(38, 13);
            this.widthLbl.TabIndex = 3;
            this.widthLbl.Text = "Width:";
            // 
            // heightLbl
            // 
            this.heightLbl.AutoSize = true;
            this.heightLbl.Location = new System.Drawing.Point(42, 155);
            this.heightLbl.Name = "heightLbl";
            this.heightLbl.Size = new System.Drawing.Size(41, 13);
            this.heightLbl.TabIndex = 4;
            this.heightLbl.Text = "Height:";
            // 
            // weightLbl
            // 
            this.weightLbl.AutoSize = true;
            this.weightLbl.Location = new System.Drawing.Point(39, 188);
            this.weightLbl.Name = "weightLbl";
            this.weightLbl.Size = new System.Drawing.Size(44, 13);
            this.weightLbl.TabIndex = 5;
            this.weightLbl.Text = "Weight:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(48, 48);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 13);
            this.label7.TabIndex = 6;
            // 
            // addPkgBtn
            // 
            this.addPkgBtn.Location = new System.Drawing.Point(31, 211);
            this.addPkgBtn.Name = "addPkgBtn";
            this.addPkgBtn.Size = new System.Drawing.Size(154, 39);
            this.addPkgBtn.TabIndex = 7;
            this.addPkgBtn.Text = "Add Ground Package";
            this.addPkgBtn.UseVisualStyleBackColor = true;
            this.addPkgBtn.Click += new System.EventHandler(this.addPkgBtn_Click);
            // 
            // detailsBtn
            // 
            this.detailsBtn.Location = new System.Drawing.Point(405, 19);
            this.detailsBtn.Name = "detailsBtn";
            this.detailsBtn.Size = new System.Drawing.Size(74, 49);
            this.detailsBtn.TabIndex = 8;
            this.detailsBtn.Text = "Details";
            this.detailsBtn.UseVisualStyleBackColor = true;
            this.detailsBtn.Click += new System.EventHandler(this.detailsBtn_Click);
            // 
            // sendToULBtn
            // 
            this.sendToULBtn.Location = new System.Drawing.Point(405, 87);
            this.sendToULBtn.Name = "sendToULBtn";
            this.sendToULBtn.Size = new System.Drawing.Size(74, 49);
            this.sendToULBtn.TabIndex = 9;
            this.sendToULBtn.Text = "Send to UofL";
            this.sendToULBtn.UseVisualStyleBackColor = true;
            this.sendToULBtn.Click += new System.EventHandler(this.sendToULBtn_Click);
            // 
            // sendFromULTxtBx
            // 
            this.sendFromULTxtBx.Location = new System.Drawing.Point(405, 155);
            this.sendFromULTxtBx.Name = "sendFromULTxtBx";
            this.sendFromULTxtBx.Size = new System.Drawing.Size(74, 49);
            this.sendFromULTxtBx.TabIndex = 10;
            this.sendFromULTxtBx.Text = "Send from UofL";
            this.sendFromULTxtBx.UseVisualStyleBackColor = true;
            this.sendFromULTxtBx.Click += new System.EventHandler(this.sendFromULTxtBx_Click);
            // 
            // packageListBox
            // 
            this.packageListBox.FormattingEnabled = true;
            this.packageListBox.Location = new System.Drawing.Point(217, 19);
            this.packageListBox.Name = "packageListBox";
            this.packageListBox.Size = new System.Drawing.Size(172, 186);
            this.packageListBox.TabIndex = 11;
            // 
            // originTxtBx
            // 
            this.originTxtBx.Location = new System.Drawing.Point(85, 20);
            this.originTxtBx.Name = "originTxtBx";
            this.originTxtBx.Size = new System.Drawing.Size(100, 20);
            this.originTxtBx.TabIndex = 12;
            // 
            // destinationTxtBx
            // 
            this.destinationTxtBx.Location = new System.Drawing.Point(85, 53);
            this.destinationTxtBx.Name = "destinationTxtBx";
            this.destinationTxtBx.Size = new System.Drawing.Size(100, 20);
            this.destinationTxtBx.TabIndex = 13;
            // 
            // lengthTxtBx
            // 
            this.lengthTxtBx.Location = new System.Drawing.Point(85, 86);
            this.lengthTxtBx.Name = "lengthTxtBx";
            this.lengthTxtBx.Size = new System.Drawing.Size(100, 20);
            this.lengthTxtBx.TabIndex = 14;
            // 
            // widthTxtBx
            // 
            this.widthTxtBx.Location = new System.Drawing.Point(85, 119);
            this.widthTxtBx.Name = "widthTxtBx";
            this.widthTxtBx.Size = new System.Drawing.Size(100, 20);
            this.widthTxtBx.TabIndex = 15;
            // 
            // heightTxtBx
            // 
            this.heightTxtBx.Location = new System.Drawing.Point(85, 152);
            this.heightTxtBx.Name = "heightTxtBx";
            this.heightTxtBx.Size = new System.Drawing.Size(100, 20);
            this.heightTxtBx.TabIndex = 16;
            // 
            // weightTxtBx
            // 
            this.weightTxtBx.Location = new System.Drawing.Point(85, 185);
            this.weightTxtBx.Name = "weightTxtBx";
            this.weightTxtBx.Size = new System.Drawing.Size(100, 20);
            this.weightTxtBx.TabIndex = 17;
            // 
            // clearBtn
            // 
            this.clearBtn.Location = new System.Drawing.Point(313, 211);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(76, 39);
            this.clearBtn.TabIndex = 18;
            this.clearBtn.Text = "Clear List";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // clearTextBoxBtn
            // 
            this.clearTextBoxBtn.Location = new System.Drawing.Point(217, 211);
            this.clearTextBoxBtn.Name = "clearTextBoxBtn";
            this.clearTextBoxBtn.Size = new System.Drawing.Size(76, 39);
            this.clearTextBoxBtn.TabIndex = 19;
            this.clearTextBoxBtn.Text = "Clear Text";
            this.clearTextBoxBtn.UseVisualStyleBackColor = true;
            this.clearTextBoxBtn.Click += new System.EventHandler(this.clearTextBoxBtn_Click);
            // 
            // Program4form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(496, 277);
            this.Controls.Add(this.clearTextBoxBtn);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.weightTxtBx);
            this.Controls.Add(this.heightTxtBx);
            this.Controls.Add(this.widthTxtBx);
            this.Controls.Add(this.lengthTxtBx);
            this.Controls.Add(this.destinationTxtBx);
            this.Controls.Add(this.originTxtBx);
            this.Controls.Add(this.packageListBox);
            this.Controls.Add(this.sendFromULTxtBx);
            this.Controls.Add(this.sendToULBtn);
            this.Controls.Add(this.detailsBtn);
            this.Controls.Add(this.addPkgBtn);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.weightLbl);
            this.Controls.Add(this.heightLbl);
            this.Controls.Add(this.widthLbl);
            this.Controls.Add(this.lengthLbl);
            this.Controls.Add(this.destLbl);
            this.Controls.Add(this.originLbl);
            this.Name = "Program4form";
            this.Text = "Program 4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label originLbl;
        private System.Windows.Forms.Label destLbl;
        private System.Windows.Forms.Label lengthLbl;
        private System.Windows.Forms.Label widthLbl;
        private System.Windows.Forms.Label heightLbl;
        private System.Windows.Forms.Label weightLbl;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button addPkgBtn;
        private System.Windows.Forms.Button detailsBtn;
        private System.Windows.Forms.Button sendToULBtn;
        private System.Windows.Forms.Button sendFromULTxtBx;
        private System.Windows.Forms.ListBox packageListBox;
        private System.Windows.Forms.TextBox originTxtBx;
        private System.Windows.Forms.TextBox destinationTxtBx;
        private System.Windows.Forms.TextBox lengthTxtBx;
        private System.Windows.Forms.TextBox widthTxtBx;
        private System.Windows.Forms.TextBox heightTxtBx;
        private System.Windows.Forms.TextBox weightTxtBx;
        private System.Windows.Forms.Button clearBtn;
        private System.Windows.Forms.Button clearTextBoxBtn;
    }
}

