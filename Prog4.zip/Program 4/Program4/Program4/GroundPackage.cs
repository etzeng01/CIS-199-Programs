﻿/* Emily Zeng
 * CIS 199-01
 * Program 4
 * Due: 4/24/16
 * 
 * File: GroundPackage.cs
 * This file creates a GroundPackage class that takes the dimensions and weight of a 
 * package as well as how far it's traveling and computes the cost. */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{
    public class GroundPackage
    {

        public const int DEFAULT_VALUE = 1;         // Value used for initial measurements   
        public const int DEFAULT_ZIP = 11111;       // Value used for initial zip codes
        public const int DIVISOR = 10000;           // Divide by 10,000 to calculate distance between zip codes
        public const double DIMENSION_FACTOR = .20; // Dimension factor for cost calculation
        public const double WEIGHT_FACTOR = .50;    // Weight factor for cost calculation
        private int _origin;            // 00000 - 99999
        private int _destination;       // 00000 - 99999
        private double _length;         // > 0
        private double _width;          // > 0
        private double _height;         // > 0
        private double _weight;         // > 0
        private double cost;                        // Holds cost of package

        // Constructor
        // Precondition: origin >= 00000
        //               destination >= 00000
        //               length > 0
        //               width > 0
        //               height > 0
        //               weight > 0
        // Postcondition: GroundPackage object initialized with specified origin, destination, length, width, height, and weight
        public GroundPackage(int origin, int destination, double length, double width, double height, double weight)
        {
            // Start with default values
            OriginZip = DEFAULT_ZIP;
            DestinationZip = DEFAULT_ZIP;
            Length = DEFAULT_VALUE;
            Width = DEFAULT_VALUE;
            Height = DEFAULT_VALUE;
            Weight = DEFAULT_VALUE;
            
            // Use properties to set if invalid data is sent
            OriginZip = origin;             
            DestinationZip = destination;   
            Length = length;                
            Width = width;                
            Height = height;               
            Weight = weight;                
        }

        // int property OriginZip
        public int OriginZip
        {
            // Precondition: None
            // Postcondition: Origin zip returned
            get
            {
                return _origin;
            }

            // Precondition: 00000 <= value <= 99999
            // Postcondition: OriginZip set to specified value
            set
            {
                if (value >= 00000 && value <= 99999)
                {
                    _origin = value;
                }
            }
        }

        // int property DestinationZip
        public int DestinationZip
        {
            // Precondition: None
            // Postcondition: Destination zip returned
            get
            {
                return _destination;
            }

            // Precondition: 00000 <= value <= 99999
            // Postcondition: Destination zip set to specified value
            set
            {
                if (value >= 00000 && value <= 99999)
                {
                    _destination = value;
                }
            }
        }

        // double property Length
        public double Length
        {
            // Precondition: None
            // Postcondition: Length returned
            get
            {
                return _length;
            }

            // Precondition: Value > 0
            // Postcondition: Length set to specified value
            set
            {
                if (value > 0)
                {
                    _length = value;
                }
            }
        }

        // double property Width
        public double Width
        {
            // Precondition: None
            // Postcondition: Width returned
            get
            {
                return _width;
            }

            // Precondition: Value > 0
            // Postcondition: Width set to specified value
            set
            {
                if (value > 0)
                {
                    _width = value;
                }
            }
        }


        // double property Height
        public double Height
        {
            // Precondition: None
            // Postcondition: Height returned
            get
            {
                return _height;
            }

            // Precondition: Value > 0
            // Postcondition: Height set to specified value
            set
            {
                if (value > 0)
                {
                    _height = value;
                }
            }
        }

        // double property Weight
        public double Weight
        {
            // Precondition: None
            // Postcondition: Weight returned
            get
            {
                return _weight;
            }

            // Precondition: Value > 0
            // Postcondition: Weight set to specified value
            set
            {
                if (value > 0)
                {
                    _weight = value;
                }
            }
        }

        // Precondition: None
        // Postcondition: Zone distance calculated and returned
        public int ZoneDistance
        {
            get
            {
                return Math.Abs(OriginZip / DIVISOR) - Math.Abs(DestinationZip / DIVISOR);
            }
        }

        // Precondition: ZoneDistance calculated
        // Postcondition: Cost of shipping the package the designated distance returned
        public double CalcCost()
        {
            cost = DIMENSION_FACTOR * (Length + Width + Height) + WEIGHT_FACTOR * (ZoneDistance + 1) * (Weight);
            return cost;
        }

        // Precondition: None
        // Postcondition: Returns string in MessageBox displaying the details of the package
        public override string ToString()
        {
            string output = "Origin Zip:" + " " + OriginZip.ToString() + Environment.NewLine + "Destination Zip:" + " " + DestinationZip.ToString() + Environment.NewLine + "Length:" + " " + Length.ToString() + Environment.NewLine + "Width:" + " " + Width.ToString() + Environment.NewLine + "Height:" + " " + Height.ToString() + Environment.NewLine + "Weight:" + " " + Weight.ToString();
            return output; 
        }
    }
}
