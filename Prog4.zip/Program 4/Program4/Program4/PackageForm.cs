﻿/* Emily Zeng
 * CIS 199-01
 * Program 4
 * Due: 4/24/16
 * 
 * File: PackageForm.cs
 * This file creates a form that tests the GroundPackage class. It also updates the origin and destination zips to UofL's zip code when asked. */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program4
{
    public partial class Program4form : Form
    {
        List<GroundPackage> packageList = new List<GroundPackage>(); // Create list named packageList to hold Packages

        const int UL = 40292;   // Declare named constant UL to hold UL's zip code

        // Precondition: None
        // Postcondition: Form is constructed and ready to display
        public Program4form()
        {
            InitializeComponent();
        }

        // Precondition: 00000 <= origin zip <= 99999
        //               00000 <= destination zip <= 99999
        //               length > 0
        //               width > 0
        //               height > 0
        //               weight > 0
        //               
        // Postcondition: Adds package to the packageListBox if TryParse is successful and input is within range.
        //                If TryParse fails or input is out of range, error message appears in message box
        private void addPkgBtn_Click(object sender, EventArgs e)
        {
            int origin;         // Variable to hold origin zip
            int destination;    // Variable to hold destination zip
            double length;      // Variable to hold length
            double width;       // Variable to hold width
            double height;      // Variable to hold height
            double weight;      // Variable to hold weight
            double cost;        // Variable to hold cost

            if (int.TryParse(originTxtBx.Text, out origin))    
            {
                if (origin >= 00000 && origin <= 99999)       
                {
                    if (int.TryParse(destinationTxtBx.Text, out destination))  
                    {   
                        if (destination >= 00000 && destination <= 99999)       
                        {
                            if (double.TryParse(lengthTxtBx.Text, out length))  
                            {   
                                if (length > 0)                                 
                                {
                                    if (double.TryParse(widthTxtBx.Text, out width))    
                                    {
                                        if (width > 0)                                  
                                        {
                                            if (double.TryParse(heightTxtBx.Text, out height))  
                                            {
                                                if (height > 0)                                           
                                                {
                                                    if (double.TryParse(weightTxtBx.Text, out weight))  
                                                    {
                                                        if (weight > 0)                         
                                                        {
                                                            GroundPackage package = new GroundPackage(origin, destination, length, width, height, weight);  // Create GroundPackage object named package

                                                            packageList.Add(package);   // Add package to the package list

                                                            cost = package.CalcCost();  // Package cost assigned to cost variable

                                                            packageListBox.Items.Add(cost.ToString("C")); // Cost is displayed in packageListBox

                                                        }
                                                        else
                                                        {
                                                            MessageBox.Show("Enter weight greater than 0.");
                                                            weightTxtBx.Focus();
                                                        }
                                                    }
                                                    else
                                                    {
                                                        MessageBox.Show("Enter valid weight.");
                                                        weightTxtBx.Focus();
                                                    }
                                                }
                                                else
                                                {
                                                    MessageBox.Show("Enter height greater than 0.");
                                                    heightTxtBx.Focus();
                                                }
                                            }
                                            else
                                            {
                                                MessageBox.Show("Enter valid height.");
                                                heightTxtBx.Focus();
                                            }
                                        }
                                        else
                                        {
                                            MessageBox.Show("Enter width greater than 0");
                                            widthTxtBx.Focus();
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Enter valid width");
                                        widthTxtBx.Focus();
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Enter length greater than 0");
                                    lengthTxtBx.Focus();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Enter valid length");
                                lengthTxtBx.Focus();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Enter valid zip code that is between 00000-99999");
                            destinationTxtBx.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Enter valid zip code between 00000-99999");
                        destinationTxtBx.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Enter valid zip code between 00000-99999");
                    originTxtBx.Focus();
                }
            }
            else
            {
                MessageBox.Show("Enter valid zip code between 00000-99999");
                originTxtBx.Focus();
            }
        }

        // Precondition: Package is selected
        // Postcondition: Messagebox appears with the details of the package
        //                If no package is selected, error message appears
        private void detailsBtn_Click(object sender, EventArgs e)
        {
            if (packageListBox.SelectedIndex == -1)                     // Test if item is selected
            {
                MessageBox.Show("Please select a package.");
            }
            else
            {
                int position = packageListBox.SelectedIndex;             

                MessageBox.Show((packageList[position].ToString()));
            }
        }

        // Precondition: Package is selected
        // Postcondition: Package's destination zip code changed to UofL's zip code
        //                If no package is selected, error message appears
        private void sendToULBtn_Click(object sender, EventArgs e)
        {
            if (packageListBox.SelectedIndex == -1)                     // Test if item is selected
            {
                MessageBox.Show("Please select a package.");
            }
            else
            {
                int position = packageListBox.SelectedIndex;

                GroundPackage package = packageList[position];

                package.DestinationZip = UL;

                destinationTxtBx.Text = UL.ToString();

                MessageBox.Show("Destination zip has been changed to UofL's zip code, 40292.");
            }
        }

        // Precondition: User selected package from listbox and clicked on Send From UofL button.
        // Postcondition: Package's origin zip code changed to UofL's zip code
        //                If no package is selected, error message appears
        private void sendFromULTxtBx_Click(object sender, EventArgs e)
        {
            if (packageListBox.SelectedIndex == -1)                     // Test if item is selected
            {
                MessageBox.Show("Please select a package.");
            }
            else
            {
                int position = packageListBox.SelectedIndex;

                GroundPackage package = packageList[position];

                package.OriginZip = UL;

                originTxtBx.Text = UL.ToString();

                MessageBox.Show("Origin zip has been changed to UofL's zip code, 40292.");
            }
        }

        // Precondition: Use clicked on Clear List button
        // Postcondition: Package listbox is cleared
        private void clearBtn_Click(object sender, EventArgs e)
        {
            packageListBox.Items.Clear();
        }

        // Precondition: User clicked on Clear Text button
        // Postcondition: Input textboxes are cleared
        private void clearTextBoxBtn_Click(object sender, EventArgs e)
        {
            originTxtBx.Clear();
            destinationTxtBx.Clear();
            lengthTxtBx.Clear();
            widthTxtBx.Clear();
            heightTxtBx.Clear();
            weightTxtBx.Clear();
        }



    }
}
